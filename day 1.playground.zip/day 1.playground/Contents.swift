import UIKit

var greeting = "Hello, playground"
// variables
var subha = "welcomes you"
var teju = "hello"

// str,int,multiline str,bool,double,str intrpltn,const,type annotation
var quote = "life is beautiful"
var age = 28
var quotes = """
teju's  father is raghupathy
"""
var ismarried = true
var myweight = 3.47
var  party = " \(subha) to teju birthday "
let myheight = 162
var gender: String = "baby girl"
var borndate: Int = 18082020
var isactive: Bool = true
var weights: Double = 2.8


// array,sets,tuples,dict,dict def val,enum,enum ass val,enum raw val

let name = ["raghupathy", "subha", "teju","teju"]  //allow duplicates and ordered
name[1]     // index position
let myfamily = "members are \(name[1]) " //array using strimg interpolation
let name1 = (["raghu", "subhaa","raghu", "teju"])// no duplicates and unordered
var mypapa = (name: "teju", age: 1, weight: 7.8, cuteness: "overloaded")
mypapa.3 // or
mypapa.cuteness
mypapa.cuteness = "Her smile"
let name2 = ["Father": "raghupathy", "wife": "subha","age": "28"]
let name3: [String: Int] = ["age": 32, "sweet": 3]  // imp
let seperate = name2["wife"]
let display = name3["age"]
let assume = name2["teju", default: "cutie pie"]// dic def val
enum cake {
    case butterscotch
    case whiteforest
    case vennila
}
let eat = cake.vennila
enum cake1 {
    case blackforest(colour: String, tasty: Bool, rate: Int)
}
let review = cake1.blackforest(colour:"black and white", tasty:true,rate:79)
enum cake2: Int {
    case butterscotch1
    case whiteforest1 = 2
    case vennila1
}
let whiteforest = cake2(rawValue:2)

//enum costume: Bool {
//    case chudi = true
//    case saree = false
//}
//let saree = costume(rawValue: true)
//

